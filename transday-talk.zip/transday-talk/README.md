# Transday Talk

A minimalist, anonymous, ephemeral messenger.
