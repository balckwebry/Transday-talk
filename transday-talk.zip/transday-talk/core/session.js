// Session logic for ephemeral communication

function createSession() {
    const sessionId = crypto.randomUUID();
    return sessionId;
}

export { createSession };