## Transday Talk Manifesto

We don’t fight for attention. We respect it.
No names. No stars. No logs.
Freedom isn’t shadow. It’s light without cameras.
Transday Talk is a space without noise.
